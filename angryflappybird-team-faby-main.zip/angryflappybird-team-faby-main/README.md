In order to run the game, download the file from main using the green button and make a copy onto your desktop. 

The functions of the game:

1. Navagate the rocket through space avoiding pipes. Collision with pipes minus 1 life, but score stays. After all three lives are lost score is resetted.
2. Collect fuel for your rocket and gain 1 point.
3. Avoid meteors. Collision with meteor restarts the game. 
4. If meteor hits the fuel, minus 1 point.

Happy gaming!
